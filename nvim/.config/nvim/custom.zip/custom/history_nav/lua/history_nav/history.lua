local M = {}

local history_stack = {}
local current_index = 0
local is_navigating = false

function M.setup(user_opts)
  opts = vim.tbl_deep_extend("force", {}, user_opts or {})

  local group = vim.api.nvim_create_augroup("HistoryNav", { clear = true })
  vim.api.nvim_create_autocmd("BufWinEnter", {
    group = group,
    callback = function()
      local current_file = vim.api.nvim_buf_get_name(0)
      if current_file == "" then
        return
      end

      if is_navigating then
        is_navigating = false
        return
      end

      if current_index < #history_stack then
        for i = #history_stack, current_index + 1, -1 do
          table.remove(history_stack)
        end
      end

      table.insert(history_stack, current_file)
      current_index = #history_stack
    end,
  })
end

function M.navigate_back()
  if current_index > 1 then
    is_navigating = true
    current_index = current_index - 1
    local file = history_stack[current_index]
    vim.cmd("edit " .. vim.fn.fnameescape(file))
  end
end

function M.navigate_forward()
  if current_index < #history_stack then
    is_navigating = true
    current_index = current_index + 1
    local file = history_stack[current_index]
    vim.cmd("edit " .. vim.fn.fnameescape(file))
  end
end

function M.get_history()
  return history_stack
end

return M
