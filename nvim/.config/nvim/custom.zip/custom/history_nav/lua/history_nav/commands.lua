local history = require("history_nav.history")

local M = {}

function M.setup()
  vim.api.nvim_create_user_command("HistoryBack", function()
    history.navigate_back()
  end, {})

  vim.api.nvim_create_user_command("HistoryForward", function()
    history.navigate_forward()
  end, {})

  vim.keymap.set("n", "<leader>bp", ":HistoryBack<CR>", { silent = true })
  vim.keymap.set("n", "<leader>bn", ":HistoryForward<CR>", { silent = true })
end

return M
