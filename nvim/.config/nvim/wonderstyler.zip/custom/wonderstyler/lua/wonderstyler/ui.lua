-- lua/wonderstyler/ui.lua
local M = {}

--- Функция, создающая новый временный буфер и открывающая его во всплывающем окне.
--- @param content string — текст для вывода.
function M.show_popup(content)
  -- Создаём новый scratch-буфер
  local buf = vim.api.nvim_create_buf(false, true)
  vim.api.nvim_buf_set_lines(buf, 0, -1, false, vim.split(content, "\n"))

  -- Определяем размеры окна (60% от размеров редактора)
  local width = math.floor(vim.o.columns * 0.6)
  local height = math.floor(vim.o.lines * 0.6)
  local row = math.floor((vim.o.lines - height) / 2 - 1)
  local col = math.floor((vim.o.columns - width) / 2)

  -- Создаём всплывающее окно с рамкой
  vim.api.nvim_open_win(buf, true, {
    relative = "editor",
    width = width,
    height = height,
    row = row,
    col = col,
    style = "minimal",
    border = "rounded",
  })
end

return M
