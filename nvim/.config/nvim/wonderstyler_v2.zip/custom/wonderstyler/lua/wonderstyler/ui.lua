-- lua/myplugin/ui.lua
local M = {}

--- Функция для закрытия всплывающего окна.
function M.close_popup()
  local win = vim.api.nvim_get_current_win()
  vim.api.nvim_win_close(win, true)
end

--- Функция, создающая временный буфер с подсветкой синтаксиса и открывающая его во всплывающем окне.
--- @param content string — текст для вывода.
function M.show_popup(content)
  -- Создаём новый scratch-буферwon
  local buf = vim.api.nvim_create_buf(false, true)
  local lines = vim.split(content, "\n")
  vim.api.nvim_buf_set_lines(buf, 0, -1, false, lines)

  -- Устанавливаем filetype, чтобы включилась подсветка синтаксиса через treesitter.
  -- Здесь выбран "css", так как вывод представляет собой CSS-код.
  vim.api.nvim_buf_set_option(buf, "filetype", "scss")

  -- Устанавливаем локальное отображение для закрытия окна по клавише Escape.
  vim.api.nvim_buf_set_keymap(
    buf,
    "n",
    "<esc>",
    "<cmd>lua require'wonderstyler.ui'.close_popup()<CR>",
    { noremap = true, silent = true }
  )

  -- Определяем размеры и положение окна (60% от размеров редактора).
  local width = math.floor(vim.o.columns * 0.6)
  local height = math.floor(vim.o.lines * 0.6)
  local row = math.floor((vim.o.lines - height) / 2 - 1)
  local col = math.floor((vim.o.columns - width) / 2)

  -- Создаём всплывающее окно с рамкой.
  vim.api.nvim_open_win(buf, true, {
    relative = "editor",
    width = width,
    height = height,
    row = row,
    col = col,
    style = "minimal",
    border = "rounded",
  })
end

return M
