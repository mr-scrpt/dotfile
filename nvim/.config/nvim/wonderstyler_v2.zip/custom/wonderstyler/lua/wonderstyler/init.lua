-- lua/wonderstyler/init.lua
local parser = require("wonderstyler.parser")
local transformer = require("wonderstyler.transformer")
local ui = require("wonderstyler.ui")

local M = {}

--- Основная функция плагина, вызываемая по команде/клавише.
function M.show_classes()
  local bufnr = vim.api.nvim_get_current_buf()
  local lines = vim.api.nvim_buf_get_lines(bufnr, 0, -1, false)
  -- Парсим все встречающиеся class и className
  local classes = parser.parse_classes(lines)
  -- Преобразуем список классов в нужное структурированное представление
  local output = transformer.transform(classes)
  -- Показываем результат во всплывающем окне
  ui.show_popup(output)
end

--- Функция для настройки плагина (например, привязка сочетания клавиш)
function M.setup(opts)
  opts = opts or {}
  local key = opts.key or "<leader>cc"
  vim.api.nvim_set_keymap("n", key, ":lua require('wonderstyler').show_classes()<CR>", { noremap = true, silent = true })
end

return M
