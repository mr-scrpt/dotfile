local history = require("history_nav.history")
local commands = require("history_nav.commands")

local M = {}

function M.setup(opts)
  opts = opts or {}
  history.setup(opts)
  commands.setup()
end

return M
