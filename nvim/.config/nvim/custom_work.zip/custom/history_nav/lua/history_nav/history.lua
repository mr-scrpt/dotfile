local M = {}

-- Основная история — последовательность файлов, открытых "линейно"
local main_history = {}
local current_index = 0

-- При ветвлении (открытие нового файла не с конца истории)
-- будем использовать branch_cycle — массив файлов с циклической навигацией
local branch_cycle = nil -- если не nil, то находимся в режиме ветвления
local cycle_index = nil -- текущая позиция в branch_cycle

-- Флаг, чтобы не реагировать на автопереходы, вызванные самим перемещением по истории
local is_navigating = false

-- Функция записи файла в историю
local function record_file(file)
  if is_navigating then
    return
  end

  -- Если мы находимся в конце основной истории, просто дописываем файл
  if current_index == #main_history then
    if main_history[#main_history] == file then
      return
    end
    table.insert(main_history, file)
    current_index = #main_history
    -- При нормальном переходе ветка (branch_cycle) сбрасывается
    branch_cycle = nil
    cycle_index = nil
  else
    -- Мы не на конце основной истории — переходим в режим ветвления
    if not branch_cycle then
      -- Сохраняем "точку ветвления" и оставшуюся часть истории
      local branch_point = main_history[current_index]
      local future = {}
      for i = current_index + 1, #main_history do
        table.insert(future, main_history[i])
      end
      -- Создаем ветку: первым элементом будет текущий открытый файл,
      -- затем точка ветвления и оставшаяся часть основной истории.
      branch_cycle = {}
      table.insert(branch_cycle, file) -- новый файл
      table.insert(branch_cycle, branch_point) -- сохраняем точку ветвления
      for _, f in ipairs(future) do
        table.insert(branch_cycle, f)
      end
      cycle_index = 1
    else
      -- Если мы уже в режиме ветвления, то вставляем новый файл перед текущим элементом,
      -- чтобы не потерять предыдущий шаг.
      if branch_cycle[cycle_index] == file then
        return
      else
        table.insert(branch_cycle, cycle_index, file)
        -- Новая запись оказалась на той же позиции (т.е. стала текущей),
        -- а предыдущий элемент сдвинулся вправо.
      end
    end
  end
end

-- Автокоманда записывает имя файла при входе в окно (BufWinEnter)
function M.setup(user_opts)
  local group = vim.api.nvim_create_augroup("HistoryNav", { clear = true })

  vim.api.nvim_create_autocmd("BufWinEnter", {
    group = group,
    callback = function()
      local file = vim.api.nvim_buf_get_name(0)
      if file == "" then
        return
      end
      record_file(file)
    end,
  })
end

-- Переход назад по истории
function M.navigate_back()
  if branch_cycle then
    cycle_index = cycle_index + 1
    if cycle_index > #branch_cycle then
      cycle_index = 1
    end
    is_navigating = true
    vim.api.nvim_command("edit " .. vim.fn.fnameescape(branch_cycle[cycle_index]))
    is_navigating = false
  else
    if current_index > 1 then
      current_index = current_index - 1
      is_navigating = true
      vim.api.nvim_command("edit " .. vim.fn.fnameescape(main_history[current_index]))
      is_navigating = false
    end
  end
end

-- Переход вперед по истории
function M.navigate_forward()
  if branch_cycle then
    cycle_index = cycle_index - 1
    if cycle_index < 1 then
      cycle_index = #branch_cycle
    end
    is_navigating = true
    vim.api.nvim_command("edit " .. vim.fn.fnameescape(branch_cycle[cycle_index]))
    is_navigating = false
  else
    if current_index < #main_history then
      current_index = current_index + 1
      is_navigating = true
      vim.api.nvim_command("edit " .. vim.fn.fnameescape(main_history[current_index]))
      is_navigating = false
    end
  end
end

-- Для отладки: вывод содержимого основной истории и ветки (если есть)
function M.debug_history()
  print("Основная история (current_index=" .. current_index .. "):")
  for i, file in ipairs(main_history) do
    print(i, file, i == current_index and "*" or "")
  end
  if branch_cycle then
    print("Ветвление (cycle_index=" .. cycle_index .. "):")
    for i, file in ipairs(branch_cycle) do
      print(i, file, i == cycle_index and "*" or "")
    end
  end
end

return M
